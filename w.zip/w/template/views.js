firstapp.run(['$templateCache', function($templateCache) {  'use strict';

  $templateCache.put('./views/footer.html',
    "<footer><div class=container><div class=row><div class=\"col-md-6 col-sm-8\"><div class=footer-main><ul><li><a href=#>Privacy Policy</a></li><li><a href=#>Terms &amp; Conditions</a></li><li><a href=#>Copyright</a></li></ul></div></div><div class=\"col-md-6 col-sm-4\"><div class=pull-right><p>Developed by <a href=http://www.wohlig.com target=_blank>Wohlig Technology</a></p></div></div></div></div></footer>"
  );


  $templateCache.put('./views/footermenu.html',
    "<footer class=footer-menu><div class=container><div class=footer-border><div class=row><div class=col-md-6><div class=icons><a href=\"\" class=\"icons-inner fb-icon\"><i class=\"fa fa-facebook\"></i></a> <a href=\"\" class=\"icons-inner twit-icon\"><i class=\"fa fa-twitter\"></i></a> <a href=\"\" class=\"icons-inner google-icon\"><i class=\"fa fa-google-plus\"></i></a> <a href=\"\" class=\"icons-inner insta-icon\"><i class=\"fa fa-instagram\"></i></a></div></div><div class=col-md-6><div class=\"col-md-4 col-sm-4\"><h5>About</h5><ul class=footer-link><li><a href=\"\">About Us</a></li><li><a href=\"\">How it Works</a></li><li><a href=\"\">Investor</a></li></ul></div><div class=\"col-md-4 col-sm-4\"><h5>Press</h5><ul class=footer-link><li><a href=\"\">In the News</a></li><li><a href=\"\">Press Release</a></li><li><a href=\"\">Testimonal</a></li></ul></div><div class=\"col-md-4 col-sm-4\"><h5>Get In Touch</h5><ul class=footer-link><li><a href=\"\">Get support</a></li><li><a href=\"\">Contact Us</a></li><li><a href=\"\">Advertise with us</a></li></ul></div></div></div></div></div></footer>"
  );


  $templateCache.put('./views/header-login.html',
    "<header ng-controller=headerctrl><nav class=\"navbar navbar-default navbar-fixed-top\"><div class=container><div class=navbar-header><button type=button class=\"navbar-toggle collapsed\" data-toggle=collapse data-target=#nav-collapse aria-expanded=false><span class=sr-only>Toggle navigation</span> <span class=icon-bar></span> <span class=icon-bar></span> <span class=icon-bar></span></button> <a class=navbar-brand href=#/home>JacKnows</a></div><div class=\"collapse navbar-collapse\" id=nav-collapse><ul class=\"nav navbar-nav navbar-right nav-outer\"><li ng-click=showLogin();><a href=# class=\"btn btn-primary\">Login</a></li><li ng-click=showSignup();><a href=# class=\"btn btn-primary\">SignUp</a></li></ul></div></div></nav></header>"
  );


  $templateCache.put('./views/header.html',
    "<header><nav class=\"navbar navbar-default navbar-fixed-top\"><div class=container><div class=navbar-header><button type=button class=\"navbar-toggle collapsed\" data-toggle=collapse data-target=#nav-collapse aria-expanded=false><span class=sr-only>Toggle navigation</span> <span class=icon-bar></span> <span class=icon-bar></span> <span class=icon-bar></span></button> <a class=navbar-brand href=#/home>JacKnows</a></div><div class=\"collapse navbar-collapse\" id=nav-collapse><div ng-include=template.menu class=\"template menu\"></div></div></div></nav></header>"
  );


  $templateCache.put('./views/headermenu.html',
    ""
  );


  $templateCache.put('./views/menu.html',
    "<ul class=\"nav navbar-nav navbar-right\"><li ng-repeat=\"menu in navigation\" class={{menu.classis}}><a href={{menu.link}}>{{menu.name}}</a><ul class=dropdown-menu ng-if=\"menu.subnav!='';\"><li ng-repeat=\"submenu in menu.subnav\"><a href={{submenu.link}}>{{submenu.name}}</a></li></ul></li></ul>"
  );


  $templateCache.put('./views/slider.html',
    "<div class=container></div>"
  );


  $templateCache.put('./views/template.html',
    "<div ng-include=template.header class=\"template header\"></div><div ng-include=template.content class=\"template content\"></div><div ng-include=template.footermenu class=\"template footermenu\"></div><div ng-include=template.footer class=\"template footer\"></div>"
  );
}]);